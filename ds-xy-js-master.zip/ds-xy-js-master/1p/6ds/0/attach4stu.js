//
// attach - as a push wrapper
//

let a = [3,2,1]
const fn = (k) => a.push(k)

console.log(a)
fn(4)
a
