//const mySet = new Set()

const mySet = new Set(['ORDERED',"some", "unique", "unique", "unique", "values", 'UNSORTED'])
mySet
