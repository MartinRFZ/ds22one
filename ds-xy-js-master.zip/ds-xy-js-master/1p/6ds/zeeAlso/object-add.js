//
// objects
//

let obj = {}

//add key-value
obj["firstName"] = "JRG"
obj["lastName"] = "Pulido"
//vs
//obj.firstName = "JRG"
//obj.lastName = "Pulido"

//get
obj[0]//undefined
obj["firstName"]
//vs
//obj.firstName
