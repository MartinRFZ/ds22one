//
// create one file by program
// implement a method, function, non-function solution
// solve each as requested
// may use code from previous exercises
//
// SORTING


//1. bubblesort
//   sort(d)
// -> d an array of random numbers
// <- the random numbers sorted

//2. selectionsort
//   sort(d)
// -> d an array of random numbers
// <- the random numbers sorted

// forEach
// + verify is sorted
//
// + print
// - time it took
// - steps it tooks
