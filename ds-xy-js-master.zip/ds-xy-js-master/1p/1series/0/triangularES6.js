//
// tringular numbers
//

let fn = n => {
    for(let s=1,k=1; k<n+1; k++,s+=k)
	console.log(s)
}

fn(4)
