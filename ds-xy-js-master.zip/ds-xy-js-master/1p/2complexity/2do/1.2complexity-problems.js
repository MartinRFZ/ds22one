//
// create one file by program
// implement a method, function, non-function solution
// solve each as requested
//
// COMPLEXITY

//1. sieve of Eratosthenes
//   sieve(n)
// -> n integer
// <- the n first elements

//2. random number
//   random(n)
// -> n integer
// <- one random number in [1-n]
