let anArray = [2, 3, 4, 5, 6]

for (let x of anArray) {
  console.log(x)
}
