//
// loose code
// vs
// asClass code
// 

console.log('Hello stack DS world in ES6+\n')

let a=[]

a.push('a')
console.log(a)

a.push('b')
console.log(a)

a.push('d')
console.log(a)

a.forEach(k=>console.log(k))

a.pop()
console.log(a)

a.pop()
console.log(a)
console.log(a.length)

a.pop()
console.log(a)
console.log(a.length)
