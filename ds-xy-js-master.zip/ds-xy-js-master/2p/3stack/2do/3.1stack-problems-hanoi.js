/** INSTRUCTIONS
 * 
 * create one file by program
 * implement a method, function, non-function solution
 * solve each as requested
 * may use code from previous exercises
 * 
 * PROBLEM 1
 * Using a array-based stack implementation
 * solve the hanoi towers problem 
 * for 3 pegs
 * 
 */
