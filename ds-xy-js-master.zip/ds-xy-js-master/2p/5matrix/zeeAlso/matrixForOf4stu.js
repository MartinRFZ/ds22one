//
//
//
let aMatrix = [
    [1,2],//f0
    [4,5],//f1
    [7,8]//f2
]

for (let f of aMatrix) {
    for (let c of f) {
	console.log(c)
    }
}
