//
// loose code
// vs
// asClass code
// 

let Q=new Array()

Q.unshift('A')//enqueue
Q.unshift('B')
Q.unshift('C')

console.log(Q.pop())//dequeue
console.log(Q.pop())
console.log(Q.pop())
