//
// describe
//

let node1={
 data:null,
 next:null
}

let node2={
 data:null,
 next:null
}

node2.data="data2"
node1.next=node2
node1.next.data//outputs QM
