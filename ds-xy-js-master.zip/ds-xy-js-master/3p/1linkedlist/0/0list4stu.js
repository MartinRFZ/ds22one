//
// describe
//

let list = {
  key: 1,
  next: {
    key: 2,
    next: {
      key: 3,
      next: null
    }
  }
}
