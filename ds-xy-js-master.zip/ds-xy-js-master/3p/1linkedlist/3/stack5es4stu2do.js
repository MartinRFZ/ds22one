//
// imports ES5
// Node5es (data)
// Linked
//

function Stack(n) {
    //props
    this.linked = new Linked()   

    //methods
    this.push = push
    this.pop = pop
    this.peek = peek
}

//implement
