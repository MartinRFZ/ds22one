//
// imports ES5
// Node5es (data)
// Linked
//

function Queue(n) {
    //props
    this.linked = new Linked()    

    //methods
    this.enqueue = enqueue
    this.dequeue = dequeue
    this.front = front
    //this.back = back
    this.toString = toString
    this.empty = empty
}

//implement
function enqueue(){}
